
# Catalog Discount Modify Tax Basis

## Enumeration

`CatalogDiscountModifyTaxBasis`

## Fields

| Name | Description |
|  --- | --- |
| `MODIFY_TAX_BASIS` | Application of the discount will modify the tax basis. |
| `DO_NOT_MODIFY_TAX_BASIS` | Application of the discount will not modify the tax basis. |

