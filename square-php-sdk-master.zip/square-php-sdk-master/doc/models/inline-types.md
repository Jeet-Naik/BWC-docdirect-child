
# Inline Types

Object types to inline under their respective parent object in certain connect v2 responses

## Enumeration

`InlineTypes`

## Fields

| Name |
|  --- |
| `INLINE_NONE` |
| `INLINE_VARIATIONS` |
| `INLINE_ALL` |

