
# Business Booking Profile Booking Policy

Policies for accepting bookings.

## Enumeration

`BusinessBookingProfileBookingPolicy`

## Fields

| Name | Description |
|  --- | --- |
| `ACCEPT_ALL` | The seller accepts all booking requests automatically. |
| `REQUIRES_ACCEPTANCE` | The seller must accept requests to complete bookings. |

