
# Card Type

Indicates a card's type, such as `CREDIT` or `DEBIT`.

## Enumeration

`CardType`

## Fields

| Name |
|  --- |
| `UNKNOWN_CARD_TYPE` |
| `CREDIT` |
| `DEBIT` |

