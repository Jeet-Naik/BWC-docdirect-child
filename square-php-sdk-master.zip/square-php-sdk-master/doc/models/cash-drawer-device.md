
# Cash Drawer Device

## Structure

`CashDrawerDevice`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | The device Square-issued ID | getId(): ?string | setId(?string id): void |
| `name` | `?string` | Optional | The device merchant-specified name. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "id": "id0",
  "name": "name0"
}
```

